* # Tipos do serviço da computação
	![[Pasted image 20230813233650.png]]