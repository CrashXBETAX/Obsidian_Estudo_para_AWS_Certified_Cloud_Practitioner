* # ⏫ Escalabilidade vertical - Aumentar poder computacional

* # ⏩ Escalabilidade horizontal - Aumentar quantidade instâncias

* # 🌎 Alta disponibilidade - Instâncias em diferentes zonas disponibilidade
