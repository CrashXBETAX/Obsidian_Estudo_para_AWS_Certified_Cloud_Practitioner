# 📏 Regras de uso de computação na nuvem AWS

* Nenhum uso ou conteúdo ilegal, prejudicial ou ofensivo
* Nenhuma violação de segurança
* Nenhum abuso de rede
* Nenhum abuso de e-mail ou outras mensagens