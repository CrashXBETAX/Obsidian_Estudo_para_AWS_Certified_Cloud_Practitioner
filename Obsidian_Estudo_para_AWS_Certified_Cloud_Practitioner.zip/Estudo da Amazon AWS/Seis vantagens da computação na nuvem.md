* ## Troque para despesas variáveis (CAPEX para OPEX)

* ## Tenha economia de Escala

* ## Pare de adivinhar a capacidade

* ## Aumente a velocidade e a agilidade

 * ## Pare de investir em Datacenter
 
* ## Torne-se global em minutos