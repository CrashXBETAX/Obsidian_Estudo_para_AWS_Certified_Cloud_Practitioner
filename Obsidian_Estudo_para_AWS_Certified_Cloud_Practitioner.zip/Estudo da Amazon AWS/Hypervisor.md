Um hypervisor é um software que cria e executa máquinas virtuais (VMs) usando os recursos do hardware físico. Um hypervisor isola o sistema operacional do hypervisor e os recursos das máquinas virtuais, possibilitando a criação e o gerenciamento dessas máquinas.

Existem dois tipos de hypervisors:
* O tipo Bare-Metal é executado diretamente no hardware do host.
* O tipo Hosted é executado em um sistema operacional convencional como uma camada de software ou aplicação.

![[Pasted image 20230813230332.png]]