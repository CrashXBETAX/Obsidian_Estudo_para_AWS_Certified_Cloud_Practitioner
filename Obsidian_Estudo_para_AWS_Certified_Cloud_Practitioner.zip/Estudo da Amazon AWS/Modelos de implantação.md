* # ON-Premises - Nuvem privada

* # Hybrid - Nuvem mista

* # Cloud - Nuvem pública