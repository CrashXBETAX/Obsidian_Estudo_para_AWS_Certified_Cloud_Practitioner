	Crie e execute aplicações sem se preocupar com servidores
* Os servidores existem, mas você não gerencia eles
- Implantar um código, implantar uma função
- FaaS (Função como Serviço)
- Iniciou com o AWS Lambda e hoje estende para banco de dados, mensagens, armazenamento e outros